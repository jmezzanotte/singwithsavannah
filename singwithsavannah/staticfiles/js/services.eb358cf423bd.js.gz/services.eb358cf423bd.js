(function($){

	$('#slider').slick({
		dots: true, 
		infinite: true,
		autoplay: true, 
		autoplaySpeed: 4000, 
		cssEase: 'linear'
	});


})(jQuery)